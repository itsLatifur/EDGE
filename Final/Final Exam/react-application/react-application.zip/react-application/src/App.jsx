import { useState } from 'react'
import './App.css'
import Header from './assets/components/Header'

export default function App() {
  return (
    <>
      <h1>
        Today is Final Exam
      </h1>
      <Header />
    </>
  )
}
