import React from 'react';

const Header = () => {
  return (
    <h2>Exam was Easy</h2>
  );
};

export default Header;
